<?php
    //importar la conexion
    require 'includes/app.php';
    $db = conectarDB();

    //crear un email y password
    $email = "correo@correo.com";
    $password = "123456";

    $passwordHash = password_hash($password, PASSWORD_DEFAULT );

    //query par acrear el usuario
    $query3 = "INSERT INTO usuarios (email, password) VALUES ('${email}', '${passwordHash}');";
    echo $query3;


    //agregarlo a la base ded datos
    mysqli_query($db, $query3);



?>