<?php 

    if(!isset($_SESSION)){
        session_start();
    }

    $auth = $_SESSION['login'] ?? false;


    require 'includes/app.php'; //require sirve mas para incluir funciones o codigo mas complejo e importante
//include sirve para incluir mas quie todo templates 


    
    incluirTemplate('header'); /*manda a llamar la funcion incluirTemplate
    donde el header se asigna en la variable nombre*/
    
?>

    <main class="contenedor seccion">

        <h2>Casas y Depas en Venta</h2>

        <?php
            
            $limite = 10;
            include 'includes/templates/anuncios.php';
        ?>
            <?php if($auth): ?>
                <a href="admin/inicio.php" class="boton-verde">Crear propiedad</a>
            <?php endif; ?>
        </div> <!--.contenedor-anuncios-->
    </main>
    
    <?php 
  
  incluirTemplate('footer'); /*manda a llamar la funcion incluirTemplate
     donde busca el archivo templates  y posteriormente el footer que se asigno en la variable nombre*/
     
 ?>