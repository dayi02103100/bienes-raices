<?php
require '../../includes/app.php'; 

use App\vendedor;

estaAutenticado();

$vendedor = new vendedor;

    //arreglo con mensajes de errores
    $errores = vendedor::getErrores();

    if($_SERVER['REQUEST_METHOD'] ==='POST'){

        //crear una nueva instancia 
        $vendedor = new vendedor($_POST['vendedor']);
        //es similiar el new de arriba sin embargo este tendra valor el anterior esta vacio

        //validar que no hayan campos vacios
        $errores = $vendedor->validar();

        //si no hay errores: empty//verifica si esta vacio
        if(empty($errores)){
            $vendedor->guardar();
        }
    }

    incluirTemplate('header');    

?>
 <main class="contenedor seccion">
        <h1>Crear Vendedor(a)</h1>

        <a href="/admin/inicio.php" class="boton boton-amarillo">volver</a>

        <?php foreach($errores as $error): ?>
            <div class="alerta error">
            <?php echo $error;?>    
        </div>
        <?php endforeach; ?>

    

<!--GET muestra los datos en la ruta
POST oculta los datos-->
        <form class="formulario"  method="POST" action="/admin/vendedores/crear.php">
            <?php include '../../includes/templates/formulario_vendedores.php';?>
        <input type="submit" value="Crear Vendedor(a)" class="boton boton-amarillo"> 

        </form>
    </main>

<?php 
  incluirTemplate('footer');   
?>
