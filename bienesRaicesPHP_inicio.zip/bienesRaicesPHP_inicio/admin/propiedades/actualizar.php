<?php

use App\Propiedad;
use App\vendedor;
use Intervention\Image\ImageManagerStatic as Image;

require '../../includes/app.php'; 
estaAutenticado();


//validar la URL por el id de cada uno
    $id = $_GET['id'];
    $id = filter_var($id, FILTER_VALIDATE_INT);

    if(!$id){
        header('Location: /admin/inicio.php');
    }

   
    //consulta para obtener los datos de una propiedad 
    $propiedad = Propiedad::find($id);

    $vendedores = vendedor::all();


    //arreglo con mensajes de errores
    $errores = Propiedad::getErrores();

    
   //ejecutar el codigo despues de que el usuario envia el formulario
   if($_SERVER['REQUEST_METHOD'] ==='POST'){
       //asignar los atrributos
       $args = $_POST['propiedad'];
    
       $propiedad->sincronizar($args);

       $errores = $propiedad->validar();


       //subida de archivos
       //generar un nombre unico
       $nombreImagen = md5( uniqid ( rand(), true ) ) . ".jpg";
   
       if($_FILES['propiedad']['tmp_name']['imagen']){
        $imagen = Image::make($_FILES['propiedad']['tmp_name']['imagen'])->fit(800,600);//ancho,alto
        $propiedad->setImagenes($nombreImagen);
    }

    //revisar que el array de errores este vacio
    if(empty($errores)){ 
        if(isset($imagen)){
        $imagen->save(CARPETA_IMAGENES . $nombreImagen);
        }
        
        $resultado = $propiedad->guardar();      
        
    } 
    

}
   
incluirTemplate('header');    
?>

    <main class="contenedor seccion">
        <h1>Actualizar Propiedad</h1>

        <a href="/admin/inicio.php" class="boton boton-verde">volver</a>


    <?php  foreach($errores as $error): ?>
        <div class="alerta error">
            <?php echo $error;?>
        </div>
        <?php endforeach; ?>

<!--GET muestra los datos en la ruta
POST oculta los datos-->
    <form class="formulario"  method="POST"  enctype="multipart/form-data">
        <?php include '../../includes/templates/formulario_propiedades.php';?>
    <input type="submit" value="Actualizar Propiedad" class="boton boton-verde"> 

        </form>
    </main>

<?php 
  incluirTemplate('footer');   
?>