<?php 

require '../../includes/app.php'; 

use App\Propiedad;
use App\vendedor;
use Intervention\Image\ImageManagerStatic as Image;

 estaAutenticado();

   $propiedad = new Propiedad;

   //obtener todos los vendedores
   $vendedores = vendedor::all();

 
    //arreglo con mensajes de errores
    $errores = Propiedad::getErrores();


   //ejecutar el codigo despues de que el usuario envia el formulario
   if($_SERVER['REQUEST_METHOD'] ==='POST'){
       $propiedad = new Propiedad($_POST['propiedad']);

       
       //generar nombre para las imagenes guardadas
       $nombreImagen = md5( uniqid ( rand(), true ) ) . ".jpg";
   
      //realiza un resize a la imagen con intervetion 
      if($_FILES['propiedad']['tmp_name']['imagen']){
            $imagen = Image::make($_FILES['propiedad']['tmp_name']['imagen'])->fit(800,600);//ancho,alto
            $propiedad->setImagenes($nombreImagen);
      }


      //valida
       $errores =  $propiedad->validar();


   
    //exit; va aprevenir que se siga ejecutando el resto del codigo
    
    //revisar que el array de errores este vacio
    if(empty($errores)){

        

        //crear carpeta imagenes
        
            if(!is_dir(CARPETA_IMAGENES )){ //is_dir retornara si una carpeta existe o no
                 mkdir(CARPETA_IMAGENES ); //mkdir es para crear un directorio
    
            }

        //guardar la imagen servidor
            $imagen->save(CARPETA_IMAGENES  . $nombreImagen);
        
        //guardar en la base de datos
         $propiedad->crear();

        if($resultado){
            //redireccionar al usuario despues de insertar los datos
            header("Location: inicio.php?resultado= 1");
        }
        
    }
    
 
}
   
    incluirTemplate('header');    
?>

    <main class="contenedor seccion">
        <h1>crear Propiedad</h1>

        <a href="/admin/inicio.php" class="boton boton-verde">volver</a>

        <?php foreach($errores as $error): ?>
            <div class="alerta error">
            <?php echo $error;?>    
        </div>
        <?php endforeach; ?>

    

<!--GET muestra los datos en la ruta
POST oculta los datos-->
        <form class="formulario"  method="POST" action="/admin/propiedades/crear.php" enctype="multipart/form-data">
            <?php include '../../includes/templates/formulario_propiedades.php';?>
        <input type="submit" value="Crear Propiedad" class="boton boton-verde"> 

        </form>
    </main>

<?php 
  incluirTemplate('footer');   
?>