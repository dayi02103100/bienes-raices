<?Php

session_start();

$_SESSION = [];

header('location: /principal.php');


?>