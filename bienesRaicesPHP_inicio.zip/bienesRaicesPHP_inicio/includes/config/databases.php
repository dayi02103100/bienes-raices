<?php
function conectarDB(): mysqli{
    $db = new mysqli('localhost','root','root','bienesRaices');

    if(!$db){
        echo "error no se conecto";
        exit;
    }

    return $db;
}
