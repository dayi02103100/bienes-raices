<?php
require '../includes/app.php';
// Proteger esta ruta.
$auth = estaAutenticado();
 
if(!$auth){
     header('location: ../principal.php');
 }


//importar la conexion
$db = conectarDB();

//escribir el query, coonsulta
$query2 = "SELECT * FROM propiedades";

//consultar la BD
$resultadoConsulta = mysqli_query($db, $query2);


//muestra de mensaje
$resultado = $_GET['resultado'] ?? null;//?? si no
 


 if($_SERVER['REQUEST_METHOD'] === 'POST'){
     $id = $_POST['id'];
     $id = filter_var($id, FILTER_VALIDATE_INT);
     

     //elimina el archivo
     $query2 = "SELECT imagen FROM propiedades WHERE id = ${id}";
     $resultado = mysqli_query($db, $query2);
     $propiedad = mysqli_fetch_assoc($resultado);

     unlink('../imagenes/' . $propiedad['imagen']);

     //elimina la propiedad
     if($id){
         $query2 = "DELETE FROM propiedades WHERE id = ${id}";

         $resultado = mysqli_query($db, $query2);

         if($resultado){
             header('location: inicio.php?resultado=3');
         }
     }
 }

 incluirTemplate('header');    
?>

 <main class="contenedor seccion">
     <h1>Aministrador de bienes raices</h1>

         <?php 
         if(intval( $resultado) === 1): ?>
             <p class="alerta exito">Anuncio creado correctamente</p> 
             
             
         <?php elseif(intval($resultado) === 2):  ?>
             <p class="alerta exito">Anuncio actualizado correctamente</p> 
                 
                 
         <?php elseif(intval($resultado) === 3):  ?>
              <p class="alerta exito">Anuncio eliminado correctamente</p> 

             <?php endif; ?>
         

     <a href="/admin/propiedades/crear.php" class="boton boton-verde">Nueva propiedad</a>
 
 <table class="propiedades">
     <thead>
         <tr>
             <th>Id</th>
             <th>Titulo</th>
             <th>Imagen</th>
             <th>Precio</th>
             <th>Acciones</th>
         </tr>
     </thead>

     
     <tbody><!--  mostrar los resultados -->
     <?php while($propiedad = mysqli_fetch_assoc($resultadoConsulta)):?>
         <tr>
             <td class="linea">  <?php echo $propiedad['id'];?>      </td>
             <td class="linea">  <?php echo $propiedad['titulo'];?>  </td>
             <td class="linea"> <img src= "/imagenes/<?php echo $propiedad['imagen'];?> " class="imagen-tabla"></td>
             <td class="linea"> $<?php echo $propiedad['precio'];?>  </td>
             <td class="linea">

                 <form method="POST" class="w-100">
                 <input type="hidden" name="id" value="<?php echo $propiedad['id']; ?>">

                 <input type="submit" class="boton-azul-block" value="eliminar">
                 </form>

                 <a href="propiedades/actualizar.php?id=<?php echo $propiedad['id'];?>" class="boton-Nclaro-block Nclaro">Actualizar</a>
             </td>
         </tr>
         <?php endwhile; ?>
     </tbody>
 </table>
 </main>

<?php 

//cerrar la conexcion (opcional)

mysqli_close($db);
incluirTemplate('footer');   
?>