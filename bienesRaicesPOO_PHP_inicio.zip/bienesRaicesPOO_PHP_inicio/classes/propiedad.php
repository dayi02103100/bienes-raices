<?php
namespace App;

class Propiedad{
    
}

?>