<?php
function conectarDb(): mysqli{
    $db = mysqli_connect('localhost','root','root','bienesRaices');

    if(!$db){
        echo "error no se conecto";
        exit;
    }

    return $db;
}